<!doctype html>
<html lang="en">

<head>
  <style>
    a:link {
      color: white;
    }

    a:hover {
      color:pink;
      text-decoration: none;
    }
    * {
      font-family: comic sans;
    }

     
  </style>
</head>

<body>
<nav>
    <div class="container-fluid nav-wrapper aqua darken-1 z-depth-1" style="margin:0; padding-left:0; background-color:aqua;">
      <a href="index.php" class="brand-logo"style="color:black; font: weight 100px;"><img src="images\sparksfoundation.png" style="height:64px;width:90px; float:left;">&nbsp;Sparks Bank</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="index.php"style="font-size:larger;"><b>Home</b></a></li>
        <li><a href="viewdetails.php "style="font-size:larger;"><b>Customer Details</b></a></li>
        <li><a href="Moneytransaction.php"style="font-size:larger;"><b>Money Transfer</b></a></li>
        <li><a href="transactionhistory.php"style="font-size:larger;"><b>Transaction History</b></a></li>
      </ul>
    </div>
  </nav>

</body>

</html>